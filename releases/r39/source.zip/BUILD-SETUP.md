# Dinghy: lokal byggmiljö

## Omfattning

Satt upp 2026-11-20 för FM-1. Oförändrad Dinghy v0.5 byggdes och provkördes först på datorn.
Efter användarens begäran om hårdvaruprov installerades samma paket på FM-1:an och
provades med USB-MIDI och USB-ljud. Byggskriptet använder inga MIDI- eller USB-enheter.
Detta är ett fristående hårdvaruprojekt, utanför Bad Herring och Staravenir.

Tidigare rapporterat enhetsläge: original V15, originalbootloader och flashchip
UC25HQ80 / `0xB36014`. Detta lästes inte av på nytt under byggarbetet.

## Källkod och beroenden

- `dinghy/`: https://github.com/zvenson/dinghy, tagg `v0.5`, commit
  `ea1b6bf5973b11f9b4b806d08155602aaa0b505e`. Checkouten är i detached HEAD för att
  behålla den valda versionen; inga spårade filer har ändrats.
- `.build-env/jieli/toolchain`: JieLis Linux-verktyg från Dinghys
  `tools/get_toolchain.sh`, hämtade från `https://pkgman.jieliapp.com/s/linux-toolchain`.
  Arkivkatalog: `jieli-linux-toolchains-20260730.1`.
- `.build-env/ac79-sdk`: https://gitee.com/Jieli-Tech/fw-AC79_AIoT_SDK.git,
  tagg `AC79NN_SDK_V1.2.1_2023-12-13`, commit
  `d179b4484759423312073f5fbb232501aa491047`.
  Sparse checkout av `cpu/wl82/tools/uboot.boot`, `cfg_tool.bin` och
  `cfg/eq_cfg_hw.bin`. Alla tre matchar Dinghys förväntade SHA-256.
- OrbStack, Docker-context `orbstack`, Linux `amd64` på denna Apple Silicon-Mac.
- Lokal byggimage `m-vave-dinghy-build:local`, recept i `Dockerfile.build`.
  Debian Bookworm-basen är låst till en digest. GCC, Python 3 och Pillow installeras
  i imagen; versionerna av Debianpaketen är inte låsta i receptet.

Den direkta macOS-provbyggningen misslyckades eftersom Apples kompilator inte
accepterar Dinghys Linux/ELF-sektionsattribut. Lösningen är att köra både
datorversionen och firmwarebygget i Linux, utan ändringar i Dinghy.

## Bygg igen

Starta OrbStack och kör:

```sh
/Users/jmfk/code/m-vave/build-local.sh
```

Skriptet kör upstreams `tests/run_host.sh` och `build.sh --board fm1` i samma
Linux-container. Källkatalogen är monterad för byggresultaten; verktyg och SDK är
skrivskyddade. Containern saknar nätverk och har inga tilldelade hårdvaruenheter.
Skriptet innehåller inget installationssteg.

Återskapa byggimagen vid behov, efter att beroendena ovan har hämtats:

```sh
docker --context orbstack build --platform linux/amd64 \
  -f /Users/jmfk/code/m-vave/Dockerfile.build \
  -t m-vave-dinghy-build:local /Users/jmfk/code/m-vave
```

## Verifierat resultat

- `build-local.sh`: lyckades, exitkod 0.
- Datorversion: kördes och genererade WAV samt två skärmbilder.
- Upstreams firmwarekontroller: godkända, inklusive RAM-gräns, appstorlek,
  RAM-kod utan anrop och registeråtkomst inom HAL.
- App: `dinghy/build/dinghy.bin`, 56 360 byte.
- Uppdateringsloader: `dinghy/build/loader/ota.bin`, 9 062 byte.
- Firmwarepaket: `dinghy/build/dinghy.fwsc`, 612 218 byte, identitet `FM-1_990`.
- Ljudprov: `dinghy/build/host/dinghy.wav`.
- Skärmbilder: `dinghy/build/host/dinghy-1000.png` och `dinghy-3000.png`.

Detta är ett vanligt utvecklingsbygge från v0.5-källkod, utan `--release`;
paketidentiteten är därför utvecklingsidentiteten, inte releasens identitet.
Full testsvit kördes inte. Det efterföljande provet på fysisk FM-1 beskrivs nedan.
Inga commits, pushar, pull requests eller externa CI-körningar har gjorts.

## Hårdvaruprov 2026-11-20

- M-Flasher 0.12.1 verifierade den faktiskt anslutna enheten som **FM-1**, med
  **UC25HQ80 / `0xB36014`** och **stock (M-VAVE)** bootloader.
- Den installerade firmwaren före provet var **SLOOP 2.8.5**, inte original V15.
  USB-produktnamnet var `Felucca`; det namnet identifierar inte vilket instrument
  i firmwarefamiljen som körs. Feluccas editorförfrågningar gav inga svar.
- En fullständig flashbackup sparades före installationen. M-Flasher kontrollerade
  läsningen mot chipets CRC32; backupfilen kontrollerades även mot sin metadata.
  Den ursprungliga backupen finns i
  `.build-env/backups/fm1-20261120-232839.bin` med tillhörande `.json`.
  Katalogen har rättighet `0700`, filerna `0600`, och `.build-env/` ignoreras av Git.
  Backupernas innehåll och enhetsnycklar ska inte skrivas ut eller öppnas via GUI-inspektion.
- Samma lokala `dinghy/build/dinghy.fwsc` installerades via M-Flasher, som bevarade
  bootområdet. Ingen mellaninstallation av V15 och inget bootloaderbyte behövdes.
  M-Flasher sparade dessutom en automatisk backup före skrivningen.
- Skrivningen verifierades av M-Flasher mot chipets CRC32. Enheten startade och
  svarade på Dinghys oförändrade `tools/fm1_install.py --info --port Felucca` med
  **`FM-1_990 [running]`**.
- Ett USB-MIDI-prov spelade C4, E4, G4, C5 och ett C-durackord, med velocity 64
  och motsvarande note-off. Användaren bekräftade att provet fungerade.
- USB-ljud spelades in från just FM-1:ans `Felucca`-ljudingång, inte Macens mikrofon:
  `dinghy/build/hardware/dinghy-fm1-20261120.wav`, stereo, 48 kHz, cirka 7,2 sekunder.
  Inspelningen innehåller ljud (peak 10 378, RMS cirka 1 916 på 16-bitsskalan).
- Dinghys spårade källkod är fortfarande oförändrad.

Nuvarande läge: **Dinghy-utvecklingsbygge `FM-1_990` körs på FM-1:an**, med
ursprunglig bootloader. Originalet för återställning är den sparade SLOOP-backupen.

## Sequencer experiment 2026-11-21

The Dinghy checkout is now on local branch `sequencer-test` with sequencer application
changes. Earlier unchanged-build statements above describe the original v0.5 baseline.
Use `build-sequencer-test.sh` for the current focused build and see
`firmware-test/README.md` for controls and limitations. The original `build-local.sh`
builds whichever application is checked out; it no longer implies an unchanged app.
The sequencer test was subsequently installed with explicit user approval, CRC32
verified, and restarted as FM-1_990 on Felucca. The original bootloader was retained.
See firmware-test/README.md for installation and hardware-test evidence.

The subsequent menu/input revision is now installed via Dinghy's built-in USB-MIDI
updater (100% transfer and restart confirmed), after an M-Flasher operation returned
an error without a confirmed write. Post-update MIDI/USB audio passed. Menus,
immediate step toggles and individual note hold/latches are documented in
firmware-test/README.md.
